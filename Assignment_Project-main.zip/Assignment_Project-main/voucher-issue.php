<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voucher Issue</title>
</head>
<body>
    <h1>
        My reward voucher isn’t working
    </h1>

    <p>
        Please check the voucher expiry date and terms.
        If the problem continues, contact customer support for assistance.
    </p>

    <a href="participants-desktop-F&Q.php">Back to Help & FAQ</a>
    
</body>
</html>