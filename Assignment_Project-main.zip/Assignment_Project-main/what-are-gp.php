<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>What are Green Points</title>
</head>
<body>
    <h1>What are Green Points (GP)?</h1>
    <p>
        Green Points (GP) are reward points earned by completing eco-friendly activities
        such as recycling, joining sustainability programs, or participating in challenges.
    </p>

    <a href="participants-desktop-F&Q.php">Back to Help & FAQ</a>
    
</body>
</html>