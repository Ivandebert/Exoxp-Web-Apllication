<?php
$systemColor = '#53B757'
?>
