<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report a Bug</title>
</head>
<body>
    <h1>
        I think there is a bug in the app  D:
    </h1>

    <p>
        If you encounter any issues, please report the problem with details such as screenshot and steps to reproduce the bug.
    </p>

    <a href="participants-desktop-F&Q.php">Back to Help & FAQ</a>

</body>
</html>