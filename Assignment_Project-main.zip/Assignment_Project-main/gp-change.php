<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GP Total Changes</title>
</head>
<body>
    <p>
    Your GP total may change due to activity verification, expired points,
    or adjustments made after review.
    </p>

    <a href="participants-desktop-F&Q.php">Back to Help & FAQ</a>
    
</body>
</html>