<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification Time</title>
</head>
<body>
    <h1>
        How long does verification take?
    </h1>

    
    <p>
        Verification usually takes between 1 to 3 working days,
        depending on the activity submitted.
    </p>

    <a href="participants-desktop-F&Q.php">Back to Help & FAQ</a>

</body>
</html>